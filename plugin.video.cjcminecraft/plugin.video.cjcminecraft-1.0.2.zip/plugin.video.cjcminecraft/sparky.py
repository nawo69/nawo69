import xbmcaddon

MainBase = 'https://pastebin.com/raw/BeWztz03'
addon = xbmcaddon.Addon('plugin.video.cjcminecraft')