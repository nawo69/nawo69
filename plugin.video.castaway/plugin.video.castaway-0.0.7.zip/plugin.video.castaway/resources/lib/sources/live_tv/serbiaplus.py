from __future__ import unicode_literals
from resources.lib.modules import client
import re, urllib


class info():
    def __init__(self):
    	self.mode = 'serbiaplus'
        self.name = 'serbiaplus.com'
        self.icon = 'serbiaplus.png'
        self.paginated = False
        self.categorized = True
        self.multilink = False
class main():
	def __init__(self,url = 'http://castalba.tv/channels'):
		self.base = 'http://www.serbiaplus.com/'
		self.url = url

	def categories(self):
		cats = [('Sport Channels','http://www.serbiaplus.com/menu1.html'), ('Acestream channels','http://www.serbiaplus.com/menu2.html')]
		out=[]
		for cat in cats:
			ch = cat[0]
			url = cat[1]
			icon = info().icon
			out.append((url,ch,icon))
		return out

	def channels(self,url):
		self.url = url
		html = client.request(url, referer=self.base)
		channels=re.compile('<a href="(.+?)" target="_blank"><img src="(.+?/(.+?).(?:jpg|png|gif))" width=".+?" height=".+?"').findall(html)
		events = self.__prepare_channels(channels)
		return events

	def __prepare_channels(self,channels):
		new=[]
		for channel in channels:
			url = self.base + channel[0]
			img = self.base + urllib.quote(channel[1])
			title = channel[2].title()
			new.append((url,title,img))
		return new

	


