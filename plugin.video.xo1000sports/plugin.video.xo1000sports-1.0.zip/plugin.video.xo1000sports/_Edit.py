import xbmcaddon

MainBase = 'http://goo.gl/dNJJ1x'
addon = xbmcaddon.Addon('plugin.video.xo1000sports')