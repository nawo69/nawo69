# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Renegades Darts by Coldkeys & AP
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: AP
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.renegadesdarts'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "UChp18JEiARNLS3AHUS6gYpg"
YOUTUBE_CHANNEL_ID_2 = "PLqeJQVNr6CBjrmJ9uT4FvskyUy8qXfTN9"
YOUTUBE_CHANNEL_ID_3 = "PLZxPj4ksDAujQf4j-FrrUV4RaU9AxlWe9"
YOUTUBE_CHANNEL_ID_4 = "PLZxPj4ksDAuhPWmv7JdczjVkrPo_aaa2b"
YOUTUBE_CHANNEL_ID_5 = "PLZxPj4ksDAuhhcm0T8k3pi-BKqA8f1Fmj"
YOUTUBE_CHANNEL_ID_6 = "PLZxPj4ksDAugQCMcEAbNcvWzRmXryIciV"
YOUTUBE_CHANNEL_ID_7 = "PLZxPj4ksDAuj4hawQsACxLKrI-ePQNPM5"
YOUTUBE_CHANNEL_ID_8 = "PLnJp9laBeYwnuXkUN34-eb72c9-pfy7RV"
YOUTUBE_CHANNEL_ID_9 = "PLnJp9laBeYwkKv6Fy5HbwMn_M8vparKvS"
YOUTUBE_CHANNEL_ID_10 = "PLnJp9laBeYwk8K1YpqnnzGd8Qs2C-s5-b"
YOUTUBE_CHANNEL_ID_11 = "PLnJp9laBeYwnvU5JVfv3ZrbdkqHocnG25"
YOUTUBE_CHANNEL_ID_12 = "PLZxPj4ksDAuiVm0g0mUz2h36LM6jEURjT"
YOUTUBE_CHANNEL_ID_13 = "PLnJp9laBeYwk7ffET96mfb_iAc3QAB1AA"
YOUTUBE_CHANNEL_ID_14 = "PLnJp9laBeYwk-jeojc48e2fbWFZyYv3FR"
YOUTUBE_CHANNEL_ID_15 = "PLnJp9laBeYwlm84rLocw1P_SA3g15ygB1"
YOUTUBE_CHANNEL_ID_16 = "PLZxPj4ksDAuiYb8pmueTTRBUZcmsYho5P"
YOUTUBE_CHANNEL_ID_17 = "PLZxPj4ksDAuiowydh00GxY4iJ9rd86tZw"
YOUTUBE_CHANNEL_ID_18 = "PLZxPj4ksDAuh0IvTIiPRSc3ASuK12uk9S"
YOUTUBE_CHANNEL_ID_19 = "PLnJp9laBeYwnfHkibLVj-9Op4gmmrvU_t"
YOUTUBE_CHANNEL_ID_20 = "PLZxPj4ksDAuiaiiJOWL5lREDBpF9BrufI"
YOUTUBE_CHANNEL_ID_21 = "PLZxPj4ksDAuhKaBqqiPVLEelJ5q3hbs6G"
YOUTUBE_CHANNEL_ID_22 = "PLZxPj4ksDAug0FSsOgAnAGg8psO_RjyQ3"
YOUTUBE_CHANNEL_ID_23 = "PLZxPj4ksDAujRjiGtI-Ngv_71E0Zf9Bhb"
YOUTUBE_CHANNEL_ID_24 = "PLZxPj4ksDAuhWyWBgOBhEDULBh_i_JEtl"
YOUTUBE_CHANNEL_ID_25 = "PLnJp9laBeYwlxGf1qZJDd5FkRYbkV59Ij"
YOUTUBE_CHANNEL_ID_26 = "PLnJp9laBeYwmLwWDkQK7k8Pc-aIpW51JX"
YOUTUBE_CHANNEL_ID_27 = "PLnJp9laBeYwkiGQtKLGs5QgwtOyy4Jceu"
YOUTUBE_CHANNEL_ID_28 = "PL152bjytsMC6Dty0wlSwL2kc_MlkX9orS"
YOUTUBE_CHANNEL_ID_29 = "PLZxPj4ksDAui-oWgruL1ZcSSm4Cpy-JSz"
YOUTUBE_CHANNEL_ID_30 = "PL0S9lXWhMeorIQoiPP5oTW7BMdaL3HEJX"
YOUTUBE_CHANNEL_ID_31 = "PL152bjytsMC53tUup7EsvBq1l19m1YTLx"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR red]SELECT PLAYLISTS[/COLOR] 2016 PDC World Darts Championships",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2016 PDC World Championship",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Premier League",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="9 Dart Finishes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 World Darts Championship",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 International Darts Open",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BDO World Championships 2015",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Grand Slam",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 World Series Of Darts Finals",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 World Grand Prix",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 European Darts Grand Prix",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 World Cup",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 European Darts Championship",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 European Darts Matchplay",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 European Darts Open",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 BDO World Trophy",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Dutch Darts Masters",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Japan Darts Masters",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 World Matchplay",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 German Darts Masters",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 German Darts Championship",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 The Unibet Masters",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Coral UK Open",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Dubai Duty Free Darts Masters",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Auckland Darts Masters",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Sydney Darts Masters",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="2015 Perth Darts Masters",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Ladies Darts",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Gold Darts",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Darts Walk on Songs",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail=icon,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="The Story of Darts",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="http://ttblogger.primaryblogger.co.uk/files/2015/03/dart-board-300x300.jpg",
        folder=True )
run()
