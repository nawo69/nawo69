import xbmcaddon

MainBase = 'http://pastebin.com/raw/nWSYi8TR'
addon = xbmcaddon.Addon('plugin.video.ChampionSports')