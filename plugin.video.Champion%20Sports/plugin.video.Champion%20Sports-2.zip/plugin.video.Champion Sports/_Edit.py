import xbmcaddon

MainBase = 'http://goo.gl/fZDfgO'
addon = xbmcaddon.Addon('plugin.video.Champion Sports')