import xbmcaddon

MainBase = 'https://goo.gl/SfFt2a'
addon = xbmcaddon.Addon('plugin.video.DCSports')