import xbmcaddon

MainBase = 'http://kodeekrazy.net/Lily_sports/home.txt'
addon = xbmcaddon.Addon('plugin.video.Lily_sports')