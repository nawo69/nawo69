import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,base64
pipcan = base64.b64decode
dialog = xbmcgui.Dialog()
def CAT():
    CAT2()
def CAT2():

    count = 0
    BASE = 'http://pipspanel.net/browse.php?u=http%3A%2F%2Fwww.watchfree.to'
    url2 = 'http://pipspanel.net/browse.php?u=http%3A%2F%2Fwww.watchfree.to%2Fwatch-146f-Top-Gear-UK-tv-show-online-free-putlocker.html&b=0'
    r = requests.get(url2)
    match = re.compile('<div class="tv_episode_item"> <a href="(.+?)">(.+?) <span class="tv_episode_name">(.+?)</span>\n<span class="tv_episode_airdate">(.+?)</span>').findall(r.content)
    for url,episode,episodeName,links in match:
        if episode == 'E1':
            addDir('[COLOR yellow]SEASON %s[/COLOR]'%(count),'',2,'','','')
            addDir(episode+episodeName,BASE+url,2,'','','')
            count +=1
        else:
            addDir(episode+episodeName,BASE+url,2,'','','')

def CAT3(url):
                    workinghosts = ['vidzi','vodlocker','vidto']
                    primehosts = ['vidzi']
                    r = requests.get(url,headers={'user-agent': 'Mozilla/5'})
                    match = re.compile('href="/browse\.php\?u=http%3A%2F%2Fwww\.watchfree\.to%2Fgo\.php%3Fgtfo%3D(.+?)%26title%3D.+?&amp;b=0".+?</strong> - (.+?)</td>',re.DOTALL).findall(r.content)
                    for url,host in match:
                        try:
                            url = url.replace('%3D','')
                            url = base64.b64decode(url)
                            host = host.replace('.com','').replace('.net','').replace('.tv','')
                            if host in primehosts:
                                addDir2(host,url,3,'','','')
                            else:
                                addDir2(host,url,3,'','','')
                        except:
                            pass
                    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE )

def addLink(pillow,url,mode,iconimage,fanart,description):
        ok=True
        liz=xbmcgui.ListItem(pillow, iconImage=pipcan("RGVmYXVsdEZvbGRlci5wbmc="), thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": pillow, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        liz.addContextMenuItems(items=[], replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok

def hello(url):
    import urlresolver
    dp = xbmcgui.DialogProgress()
    dp.create('Grabbing Your Video','Opening Ready')
    play=xbmc.Player()
    url=urlresolver.HostedMediaFile(url).resolve()
    play.play( url ) 
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]  
        return param
def addDir(pillow,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&pillow="+urllib.quote_plus(pillow)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(pillow, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": pillow, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def addDir2(pillow,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&pillow="+urllib.quote_plus(pillow)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(pillow, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": pillow, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok            
params=get_params()
url=None
pillow=None
mode=None
iconimage=None
fanart=None
description=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        pillow=urllib.unquote_plus(params["pillow"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "pillow: "+str(pillow)

if mode==None or url==None or len(url)<1:
        print ""
        CAT()
       
elif mode==1:
        CAT(url)
elif mode==2:
        CAT3(url)
elif mode==3:
        hello(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))