import xbmcaddon

MainBase = 'http://www.sport-xplosion.com/DELIVERANCE%20TXT%20FILES/home.txt'
addon = xbmcaddon.Addon('plugin.video.DELIVERANCE')